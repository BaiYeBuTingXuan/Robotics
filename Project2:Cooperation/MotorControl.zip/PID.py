import numpy as np
import math

def realGravity(theta):
    # theta(rad)
    result = 0
    a0 = 0.08073
    a1 = -0.1086
    b1 = 0.4833
    a2 = -0.02352
    b2 = -0.004866
    w = 1.007

    # a0 = 0.08236
    # a1 = -0.0959
    # b1 = 0.4772
    # a2 = -0.006753
    # b2 = -0.005419
    # w = 0.9931
    

    result += a0

    result += a1*math.cos(w*theta)
    result += b1*math.sin(w*theta)

    result += a2*math.cos(2*w*theta)
    result += b2*math.sin(2*w*theta)

    return result


def innerStable(inner_PID_input,length=20,epislon = 0.2): # 判断内环是否稳定
    if len(inner_PID_input) >= length and abs(max(inner_PID_input)) < epislon:
        return True
    else:
        return False

class Param:
    def __init__(self,P=1,I=0,D=0,Umax=100,Umin=0):
        self.P = P
        self.I = I
        self.D = D
        self.Umax = Umax
        self.Umin = Umin

class posPID:
    def __init__(self,param,intergral=0.,last_error=0,prev_error=0):
        self.param = param
        self.intergral = intergral # 积分项，内环稳态时清零
        self.last_error = last_error # e(k-1)
        self.prev_error = prev_error # e(k-2)


    def pid(self,SP,PV):
        error = SP-PV

        self.intergral += error # 积分项累计
        intergral = max(self.param.Umin,min(self.param.Umax,intergral))
        
        output = 0
        output += self.param.P*error
        output += self.param.I*self.intergral
        output += self.param.D*(error-self.last_error) # 微分先行

        self.last_error = error

        return output
    
    def set_intergral_zero(self):
        self.intergral = 0

class incPID:
    def __init__(self,param,output=50,last_error=0,last_PV=0,prev_PV=0):
        self.param = param
        self.output = output
        self.last_error = last_error # e(k-1)
        self.last_PV = last_PV # y(k-1)
        self.prev_PV = prev_PV # y(k-2)


    def pid(self,SP,PV):
        d_output = 0
        error = SP-PV
        
        # de = P*[e(k)-e(k-1)]+I*[e(k)]+D*(-y(k)+2y(k-1)-y(k-2))
        d_output += self.param.P*(error-self.last_error)
        d_output += self.param.I*error
        d_output += self.param.D*(-PV+2*self.last_PV-self.prev_PV) # 微分先行

        self.last_error = error
        self.last_PV,self.prev_PV = PV,self.last_PV

        self.output += d_output
        self.output = max(self.param.Umin,min(self.param.Umax,self.output)) # 抗积分饱和

        return self.output


