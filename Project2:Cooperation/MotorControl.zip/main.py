import math
import time
import PID

import matplotlib.pyplot as plt

from MotorControl.MotorControl import VelControl

MAX_VEL = 5

# 速度绘制
vel_list = []
PID_list = []

MAX_LEN = 20
inner_PID_input = [0.0]*MAX_LEN # 内环PID输入值记录，如果长时间等于0，说明内环稳态，此时需要清空外环PID的积分项

# 设置串口号与波特率连接电机
motor = VelControl('COM5', 921600)

# 注册电机ID
motor.registerID(1)

# 电机（ID=1）使能
motor.setMotorMode(1, 0)

# 将当前位置设为零位
motor.setMotorMode(1, 2)
time.sleep(1)

# 设置速度为1rad/s
vel_ref = 1
vel = 1
# 设置伺服周期为0.02s（由于操作系统的原因，建议伺服周期不小于0.01s）cc
servo_time = 0.02

# 设置PID参数
param = PID.Param(P=1,I=0,D=0.0,Umax=2,Umin=-2)
pid = PID.posPID(param=param,output=0)



try:
    # 在每个伺服周期中向电机（ID=1）发送指令，并得到电机的反馈数据
    while 1:
        if abs(vel) > MAX_VEL:
            vel = MAX_VEL if vel > 0 else -MAX_VEL
        # 向电机（ID=1）发送速度指令,
        motor.send(1, vel)

        # 接收电机（ID=1）的反馈数据, [位置rad，速度rad/s，力矩N.m，MOS温度℃，电机线圈温度℃]]
        feedback = motor.feedback(1)
        if feedback:
            theta = feedback[0]
            pv = feedback[2]
            sp = PID.realGravity(theta)
            vel = pid.pid(SP=sp,PV=pv)+vel_ref
            # 判断速度是否大于最大速度

        print(vel,feedback[1])
        vel_list.append(feedback[1])
        PID_list.append(vel)

        while len(inner_PID_input) >= MAX_LEN:
            inner_PID_input.pop(0) # 弹出第一个
        inner_PID_input.append(vel-feedback[1]) # 并入

        if PID.innerStable(inner_PID_input,length=MAX_LEN): # 当内环稳定
            pid.set_intergral_zero()
            

        # 保证伺服周期的相对准确性, 0.002为程序运行补偿时间(可根据实际情况调整)
        time.sleep(servo_time-0.002)

#### 下方代码不建议更改 #####
except KeyboardInterrupt:
    # Ctrl+C 结束控制
    print("killing")
finally:
    # 停止向电机的命令发送
    motor.stopSend()
    # 电机（ID=1）                     失能, 并结束反馈接收
    motor.setMotorMode(1, 1)
    motor.stopFeedback()

    x = range(len(vel_list))
    plt.plot(x, vel_list,c='r',label='velocity')
    plt.plot(x, PID_list,c='b',label='PID output')
    plt.legend()
    plt.show()
